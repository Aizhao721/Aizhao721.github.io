(function () {  

_mrmcp = (typeof _mrmcp == 'undefined') ? {} : _mrmcp;
_mrmcp['campaign_id'] = 'none';
_mrmcp['owner_id'] = '63105e84ee3f136d95224461';
_mrmcp['creative_id'] = '63ad93279bb7823104200b3e';
_mrmcp['ga_url'] = _mrmcp['ga_url'] || (('https:' == document.location.protocol ? 'https://' : 'http://') + 'card.mugeda.com/weixin/card/ga.js');
_mrmcp['width'] = _mrmcp['width'] || 320;
_mrmcp['height'] = _mrmcp['height'] || 520;
_mrmcp['type'] = 'smart';
_mrmcp['title'] = '解洋洋《小王子》';
_mrmcp['build_number'] = parseInt('1059');
_mrmcp['publish_time'] = 'Mon Jan 02 2023 23:08:50 GMT+0800 (China Standard Time)';
_mrmcp['track_bot'] = 'http://cdn.mugeda.com/media/pages/track/track_20131030.html';
_mrmcp['data_server'] = "https://weika.mugeda.com";
})();
